"use client";

import { useState } from "react";
import { nav } from "../data";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="bar wrap">
        <a className="brand" href="#home" onClick={() => setOpen(false)}>
          Jayashree S
        </a>
        <button
          className="menu-btn"
          aria-expanded={open}
          aria-controls="main-nav"
          onClick={() => setOpen(!open)}
        >
          {open ? "Close" : "Menu"}
        </button>
        <nav id="main-nav" className={open ? "nav open" : "nav"} aria-label="Main">
          {nav.map((item) => (
            <a key={item.id} href={`#${item.id}`} onClick={() => setOpen(false)}>
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
