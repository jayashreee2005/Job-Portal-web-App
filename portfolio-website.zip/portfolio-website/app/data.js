// All the text on your website lives here. Edit this file to change your content.
export const links = {
  email: "jayashreee.s12cs@gmail.com",
  linkedin: "https://www.linkedin.com/in/jayashree-shree-356597282/",
  linkedinLabel: "linkedin.com/in/jayashree-shree-356597282",
  github: "https://github.com/jayashreee2005",
  githubLabel: "github.com/jayashreee2005",
};

export const nav = [
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "projects", label: "Projects" },
  { id: "internship", label: "Internship" },
  { id: "education", label: "Education" },
  { id: "contact", label: "Contact" },
];

export const skills = [
  { group: "Frontend", items: ["HTML", "CSS", "JavaScript", "React.js", "Next.js"] },
  { group: "Database", items: ["MySQL"] },
  { group: "Tools", items: ["Docker", "Visual Studio Code"] },
];

export const project = {
  name: "Job Portal Application",
  summary:
    "A job portal application designed to connect job seekers with employers. Includes job search, applications and employer job postings.",
  features: [
    "Job search so seekers can browse and find relevant openings",
    "Job applications submitted directly through the platform",
    "Employer dashboard for posting and managing job listings",
    "Built with React and Next.js on the frontend, MySQL for data storage, and Docker for consistent, portable deployment",
  ],
  role: "Developed responsive user interface components using React.js and CSS, created job listing and search interfaces, and worked on improving the overall user experience of the Job Portal Application.",
  learned:
    "Gained practical experience in developing a web application using React.js and Next.js, working with MySQL for data management, and understanding Docker containerization.",
  tech: ["React", "Next.js", "MySQL", "Docker"],
};

export const internship = {
  company: "Sparkout Tech",
  role: "React.js Intern",
  length: "15 days",
  points: [
    "Gained practical exposure to frontend development using React.js.",
    "Learned about building user interfaces with reusable components.",
    "Improved my understanding of React.js concepts and responsive web development.",
  ],
};

export const education = [
  { school: "Karpagam Academy of Higher Education", degree: "MCA", note: "2nd year. Expected graduation: 2027" },
  { school: "Sri GVG Visalakshi College for Women", degree: "B.Sc. Computer Science", note: "" },
];
