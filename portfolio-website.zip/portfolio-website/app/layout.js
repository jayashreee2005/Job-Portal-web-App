import { Bricolage_Grotesque, Instrument_Sans } from "next/font/google";
import "./globals.css";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display" });
const text = Instrument_Sans({ subsets: ["latin"], variable: "--font-text" });

export const metadata = {
  title: "Jayashree S | Frontend Developer",
  description:
    "Portfolio of Jayashree S, an MCA student and frontend developer working with React.js and Next.js.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${text.variable}`}>
      <body>{children}</body>
    </html>
  );
}
