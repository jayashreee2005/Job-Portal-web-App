import Header from "./components/Header";
import { links, skills, project, internship, education } from "./data";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <section id="home" className="hero wrap">
          <div className="hero-text">
            <p className="kicker">Hi, I'm</p>
            <h1>Jayashree S</h1>
            <p className="role">Frontend Developer working with React.js and Next.js</p>
            <p className="lead">
              I'm an MCA student who builds responsive, user-friendly web applications. I'm looking for an
              entry-level Frontend Developer role where I can contribute to real projects.
            </p>
            <div className="actions">
              <a className="btn" href="#projects">View my project</a>
              <a className="btn ghost" href="#contact">Contact me</a>
            </div>
          </div>

          <div className="mock" aria-hidden="true">
            <div className="mock-bar"><span /><span /><span /></div>
            <div className="mock-search">Search jobs</div>
            {["Frontend Developer", "React Developer", "Software Developer"].map((t, i) => (
              <div className="mock-card" key={t}>
                <div>
                  <strong>{t}</strong>
                  <small>{["React, Next.js", "React, CSS", "JavaScript, MySQL"][i]}</small>
                </div>
                <em>Apply</em>
              </div>
            ))}
          </div>
        </section>

        <section id="about" className="section wrap">
          <h2>About me</h2>
          <div className="prose">
            <p>
              I'm an MCA student at Karpagam Academy of Higher Education, and I hold a B.Sc. in Computer
              Science. I enjoy turning ideas into clean, responsive interfaces with React.js and Next.js, and I
              am growing my skills in databases and containers with MySQL and Docker.
            </p>
            <p>
              My goal is an entry-level Frontend Developer role where I can learn from a team, ship real
              features, and keep improving as a developer.
            </p>
          </div>
        </section>

        <section id="skills" className="section wrap">
          <h2>Skills</h2>
          <dl className="skills">
            {skills.map((s) => (
              <div className="skill-row" key={s.group}>
                <dt>{s.group}</dt>
                <dd>
                  {s.items.map((i) => (
                    <span className="pill" key={i}>{i}</span>
                  ))}
                </dd>
              </div>
            ))}
          </dl>
        </section>

        <section id="projects" className="section wrap">
          <h2>Project</h2>
          <article className="card project">
            <h3>{project.name}</h3>
            <div className="tags">
              {project.tech.map((t) => (
                <span className="pill" key={t}>{t}</span>
              ))}
            </div>
            <p>{project.summary}</p>
            <ul>
              {project.features.map((f) => (
                <li key={f}>{f}</li>
              ))}
            </ul>
            <p><strong>My role:</strong> {project.role}</p>
            <p><strong>What I learned:</strong> {project.learned}</p>
            <a className="btn" href={links.github} target="_blank" rel="noopener noreferrer">
              See my code on GitHub
            </a>
          </article>
        </section>

        <section id="internship" className="section wrap">
          <h2>Internship</h2>
          <article className="card">
            <h3>{internship.company}</h3>
            <p className="meta">{internship.role}, {internship.length}</p>
            <ul>
              {internship.points.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
          </article>
        </section>

        <section id="education" className="section wrap">
          <h2>Education</h2>
          <ol className="timeline">
            {education.map((e) => (
              <li key={e.school}>
                <h3>{e.degree}</h3>
                <p>{e.school}</p>
                {e.note && <p className="meta">{e.note}</p>}
              </li>
            ))}
          </ol>
        </section>

        <section id="contact" className="section wrap">
          <h2>Contact</h2>
          <p className="prose">Open to entry-level Frontend Developer roles. The quickest way to reach me is email.</p>
          <ul className="contact">
            <li><span>Email</span><a href={`mailto:${links.email}`}>{links.email}</a></li>
            <li><span>LinkedIn</span><a href={links.linkedin} target="_blank" rel="noopener noreferrer">{links.linkedinLabel}</a></li>
            <li><span>GitHub</span><a href={links.github} target="_blank" rel="noopener noreferrer">{links.githubLabel}</a></li>
          </ul>
        </section>
      </main>
      <footer className="footer wrap">
        <p>Jayashree S. Built with Next.js and React.</p>
      </footer>
    </>
  );
}
