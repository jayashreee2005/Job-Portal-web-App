# Jayashree S - Portfolio Website

Built with Next.js 14 (App Router) and React.

## Run it on your laptop
1. Install Node.js (LTS) from https://nodejs.org, then check: `node -v` and `npm -v`
2. Open this folder in VS Code, then Terminal > New Terminal
3. `npm install`
4. `npm run dev`
5. Open http://localhost:3000

## Edit your content
All text (skills, project, internship, education, links) is in `app/data.js`.
Colors are the variables at the top of `app/globals.css`.

## Put it on GitHub
```
git init
git add .
git commit -m "Add portfolio website"
git branch -M main
git remote add origin https://github.com/jayashreee2005/portfolio-website.git
git push -u origin main
```
(Create an empty repository named `portfolio-website` on github.com first.)

## Deploy on Vercel
1. Sign in at https://vercel.com with GitHub
2. Add New > Project > import `portfolio-website`
3. Keep the default settings and press Deploy. You get a public URL.
